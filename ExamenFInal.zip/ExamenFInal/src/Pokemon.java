import java.util.Arrays;

public class Pokemon {
	public int id;
	public String tipos[];
	public String nombre;
	public String debilidades[];
	public Long ataque;
	public Long defenza;
	public String movimientos[];
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String[] getTipos() {
		return tipos;
	}
	public void setTipos(String[] tipos) {
		this.tipos = tipos;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String[] getDebilidaddes() {
		return debilidades;
	}
	public void setDebilidaddes(String[] debilidaddes) {
		this.debilidades = debilidaddes;
	}
	public Long getAtaque() {
		return ataque;
	}
	public void setAtaque(Long ataque) {
		this.ataque = ataque;
	}
	public Long getDefenza() {
		return defenza;
	}
	public void setDefenza(Long defenza) {
		this.defenza = defenza;
	}
	public String[] getMovimientos() {
		return movimientos;
	}
	public void setMovimientos(String[] movimientos) {
		this.movimientos = movimientos;
	}
	public void mostrarDebilidades() {
		for(int i=0;i<debilidades.length;i++) {
			System.out.println(debilidades[i]);
		}
	}
	
	public Pokemon(int id, String[] tipos,String nombre, String[] debilidades, Long ataque, Long defenza, String[] movimientos) {
		super();
		this.id = id;
		this.tipos = tipos;
		this.debilidades = debilidades;
		this.ataque = ataque;
		this.defenza = defenza;
		this.movimientos = movimientos;
	}
	@Override
	public String toString() {
		return "la id del pokemon es: " + id + " sus tipos son " + Arrays.toString(tipos) + " su nombre es " +nombre + " sus deblidiades son "
				+ Arrays.toString(debilidades) + " su valor de ataque es " + ataque + " su valor de defenza es " + defenza + " sus movimentos son "
				+ Arrays.toString(movimientos);
	}
	
}
