import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("hola ash");
		System.out.println("ingresa una opcion");
		ArrayList<LiderGimnasio> lista=new ArrayList<>();
		Scanner datos=new Scanner(System.in);
		while(true) {
			System.out.println("1. agregar nuevo lider");
			System.out.println("2. mostrar datos de los pokemones");
			System.out.println("3. mostrar los datos de los lideres");
			System.out.println("4. salir");
			int opcion=datos.nextInt();
			switch(opcion) {
			case 1:
				System.out.println();
				System.out.println("Ingrese el nombre del lider");
				String nombre=datos.next();
				System.out.println("Ingrese la clase del lider");
				String clase=datos.next();
				System.out.println("ingrese el tipo del lider");
				String tipo=datos.next();
				System.out.println("ingrese la cantidad de ducles favoritos");
				int owo=datos.nextInt();
				String[] dulceFavorito=new String[owo];
				for(int i=0;i<owo;i++) {
					System.out.println("ingrese un dulce favorito");
					dulceFavorito[i]=datos.next();
				}
				System.out.println("ingrese la cantidad de pokemones que tiene el lider");
				int uwu=datos.nextInt();
				Pokemon[] pp=new Pokemon[uwu];
				for(int i=0;i<uwu;i++) {
					System.out.println("ingrese la id del pokemon");
					int id=datos.nextInt();
					System.out.println("ingrese la cantidad de tipos del pokemon");
					int ewe=datos.nextInt();
					String[] tipos=new String[ewe];
					for(int j=0;j<tipos.length;j++) {
						System.out.println("ingrese un tipo");
						tipos[j]=datos.next();
					}
					System.out.println("ingrese el nombre del pokemon");
					String nombreP=datos.next();
					System.out.println("ingrese la cantidad de debilidades del pokemon");
					int a=datos.nextInt();
					String[] debilidades=new String[a];
					for(int j=0;j<a;j++) {
						System.out.println("ingrese una debilidad");
						debilidades[j]=datos.next();
					}
					System.out.println("ingrese el ataque del pokemon");
					Long ataque=datos.nextLong();
					System.out.println("ingrese la defenza del pokemon");
					Long defenza=datos.nextLong();
					System.out.println("ingrese la cantidad de movimientos del pokemon");
					int ah=datos.nextInt();
					String[] movimientos=new String[ah];
					for(int j=0;j<ah;j++) {
						System.out.println("ingrese un movimento");
						movimientos[j]=datos.next();
					}
					pp[i]=new Pokemon(id,tipos,nombreP,debilidades,ataque,defenza,movimientos);
				}
				System.out.println("ingrese la ciudad del lider de gimnasio");
				String ciudad=datos.next();
				System.out.println("ingrese la fuerza del lider de gimnasio");
				Long fuerza=datos.nextLong();
				lista.add(new  LiderGimnasio(nombre,clase,tipo,dulceFavorito,pp,ciudad,fuerza));
				break;
			case 2:
				for(LiderGimnasio l:lista) {
					l.listaPokemons();
				}
				break;
			case 3:
				for(LiderGimnasio l:lista) {
					System.out.println(lista.toString());
				}
				break;
			case 4:
				System.out.println("Adios");
				return;
			default:
				System.out.println("ingrese una opcion valida");
			}
		}
	}

}
