import java.util.Arrays;

public class LiderGimnasio {
	public String nombre;
	public String clase;
	public String tipo;
	public String dulceFavorito[];
	public Pokemon[] pokemons;
	public String ciudad;
	public long fuerza;
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getClase() {
		return clase;
	}
	public void setClase(String clase) {
		this.clase = clase;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	public String[] getDulceFavorito() {
		return dulceFavorito;
	}
	public void setDulceFavorito(String[] dulceFavorito) {
		this.dulceFavorito = dulceFavorito;
	}
	public Pokemon[] getPokemons() {
		return pokemons;
	}
	public void setPokemons(Pokemon[] pokemons) {
		this.pokemons = pokemons;
	}
	public String getCiudad() {
		return ciudad;
	}
	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}
	public long getFuerza() {
		return fuerza;
	}
	public void setFuerza(long fuerza) {
		this.fuerza = fuerza;
	}
	public void mostrarPokemon() {
		for(int i=0;i<pokemons.length;i++) {
			System.out.println(pokemons[i]);
		}
	}
	
	public LiderGimnasio(String nombre, String clase, String tipo, String[] dulceFavorito, Pokemon[] pokemons,
			String ciudad, long fuerza) {
		super();
		this.nombre = nombre;
		this.clase = clase;
		this.tipo = tipo;
		this.dulceFavorito = dulceFavorito;
		this.pokemons = pokemons;
		this.ciudad = ciudad;
		this.fuerza = fuerza;
	}
	@Override
	public String toString() {
		return "El nombre del lider de gimansio es " + nombre + " con clase " + clase + ". el tipo que usa es " + tipo + " sus dulces favoritos son "
				+ Arrays.toString(dulceFavorito) + " los pokemones que usa son " + Arrays.toString(pokemons) +  " es lider de la ciudad "
				+ ciudad + " su fuerza es " + fuerza;
	}
	public void listaPokemons() {
		for(int i=0;i<pokemons.length;i++) {
			System.out.println(pokemons[i]);
		}
	}
	public void listaLideres() {
		
	}
}
